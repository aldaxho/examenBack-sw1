
package com.example.demo.auto.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.auto.model.auto;

public interface autoRepository extends JpaRepository<auto, Long> {
}
